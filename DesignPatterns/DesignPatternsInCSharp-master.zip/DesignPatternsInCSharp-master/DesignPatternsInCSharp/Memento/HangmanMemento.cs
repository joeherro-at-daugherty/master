﻿namespace DesignPatternsInCSharp.Memento
{
    public sealed class HangmanMemento
    {
        internal char[] Guesses { get; set; }
    }
}
