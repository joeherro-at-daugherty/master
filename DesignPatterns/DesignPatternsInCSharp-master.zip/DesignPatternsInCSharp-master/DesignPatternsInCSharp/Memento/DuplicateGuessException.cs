﻿using System;

namespace DesignPatternsInCSharp.Memento
{
    public class DuplicateGuessException : Exception
    {
    }
}
