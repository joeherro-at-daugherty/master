﻿namespace DesignPatternsInCSharp.Proxy.ProtectiveProxy.Tests
{
    public class TestConstants
    {
        public const string TEST_DOCUMENT_NAME = "test name";
        public const string TEST_DOCUMENT_CONTENT = "test content";
    }
}
